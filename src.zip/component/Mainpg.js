import './Mainpg.css';

export default function Mainpg() {
    return (
        <div className="main">
            <div className="Center">
                <h1>Find the workout for you</h1>
            </div>
            <div>
                <h3>Get powerful workout recommendations</h3>
                <p>Let's Go</p>
            </div>
            <div>
                <h3>Find your own sports facilities near you</h3>
                <p>Let's Go</p>
            </div>
        </div>
    );
}