import dummy from "../db/data.json";

export default function Recomm_answer() {

    const Qnum = 1;
    const Anslist = dummy.question.filter(question => question.id === Qnum);
    return (
        <li>
            <ul>
            {Anslist.FindAnswer}
            </ul>
        </li>
    )
}