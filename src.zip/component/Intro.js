import './Intro.css';

export default function Intro() {
    return (
        <div className="Intro">
            <div className="Txt">
                <h2>서비스 소개</h2>
                <p>저희 사이트는 개인화된 생활체육 추천서비스를 제공합니다.</p>
            </div>
            <div className="Txt">
                <h2>사회적 가치</h2>
                <p>저희는 소외계층도 생활체육에 참여할 수 있도록 맞춤형 추천 서비스를 제공합니다.</p>
            </div>
            <div className="Txt">
                <h2>팀 소개</h2>
                <p>저희는 산업경영공학부 19학번 동기 4명으로 구성 되어 있습니다.</p>
            </div>
        </div>
    );
}