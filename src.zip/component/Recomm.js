import dummy from "../db/data.json";
import Recomm_answer from "../component/Recomm_answer";

export default function Recomm() {
    return <><ul className="list_q">
        {dummy.question.map(question => (
            <li key={question.id}>Q {question.Question}</li>
        ))}
        </ul>
        <Recomm_answer />
    </>
}