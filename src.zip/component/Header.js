import './Header.css'; 
import {Link} from "react-router-dom";

const MenuItem = ({active, children, to}) => (
    <div className="menu-item">{children}</div>
);

export default function Header() {
    return <div className="menu">
        <MenuItem>
            <Link to="/">메인</Link></MenuItem>
        <MenuItem>
            <Link to="/intro">소개</Link></MenuItem>
        <MenuItem>
            <Link to="/recomm">운동 추천</Link></MenuItem>
        <MenuItem>체육 시설</MenuItem>
        <MenuItem>
            <Link to="/KUinfo">KU 체육 정보</Link></MenuItem>
        <MenuItem>프로그램</MenuItem>
    </div>
}