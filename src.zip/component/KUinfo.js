import { useState } from "react";

export default function KUinfo() {

    const [search, setSearch] = useState("");
    const onChange = (e) => {
        setSearch(e.target.value)
    }

    let [글제목, 제목변경] = useState(['동아리','수업','교내 시설'])
    let [글내용, 내용변경] = useState(['KUTC','교양테니스1','프론티어 기숙사 테니스장'])

    return (
        <div>
            <input type="text" value={search} onChange={onChange} />
            <Result title={글제목[0]} body={글내용[0]}></Result>
            <Result title={글제목[1]} body={글내용[1]}></Result>
            <Result title={글제목[2]} body={글내용[2]}></Result>
        </div>

    );
}

function Result(props){
    return (
        <div className='list'>
            <h4>{props.title}</h4>
            <p>{props.body}</p>
        </div>
    )
}